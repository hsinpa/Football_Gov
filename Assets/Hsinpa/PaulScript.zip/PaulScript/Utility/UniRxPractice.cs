﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UniRxPractice : MonoBehaviour {

	// [SerializeField]
	// Button bt;
	// /// Start is called on the frame when a script is enabled just before
	// /// any of the Update methods is called the first time.
	// /// </summary>
	// void Start()
	// {
	// 	var subject = new Subject<string>();
	// 	WriteSequenceToConsole(subject);
	// 	subject.OnNext("a");
	// 	subject.OnNext("b");
	// 	subject.OnNext("c");
	// }
	// static void WriteSequenceToConsole(IObservable<string> sequence)
	// {
	// 	//The next two lines are equivalent.
	// 	//sequence.Subscribe(value=>Console.WriteLine(value));
	// 	sequence.Subscribe(Debug.Log);
	// }


}
